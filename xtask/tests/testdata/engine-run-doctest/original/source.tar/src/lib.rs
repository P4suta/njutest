// SPDX-FileCopyrightText: 2026 njutest contributors
// SPDX-License-Identifier: MIT OR Apache-2.0

//! Three functions: one the tests and the documentation both exercise, one only the documentation does, and one neither does, whose example only has to fail to compile.

/// Twice `n`.
///
/// ```
/// assert_eq!(fixture_doctest::double(2), 4);
/// ```
pub fn double(n: i32) -> i32 {
    n * 2
}

/// Half of `n`. Only this example exercises it, so only this example can notice a mutation of it.
///
/// ```
/// assert_eq!(fixture_doctest::half(4), 2);
/// ```
pub fn half(n: i32) -> i32 {
    n / 2
}

/// A third of `n`, documented without an example that runs, so nothing runs it; the one it has must not compile, which rustdoc checks alone, outside the merged binary.
///
/// ```compile_fail
/// let third: u8 = fixture_doctest::third(3);
/// ```
pub fn third(n: i32) -> i32 {
    n / 3
}

#[cfg(test)]
mod tests {
    #[test]
    fn doubling_two_is_four() {
        assert_eq!(super::double(2), 4);
    }
}
